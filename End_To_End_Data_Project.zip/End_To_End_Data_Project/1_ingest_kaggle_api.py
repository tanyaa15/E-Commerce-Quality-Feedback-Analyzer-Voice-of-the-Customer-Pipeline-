import os
import pandas as pd
from kaggle.api.kaggle_api_extended import KaggleApi
import zipfile

def ingest_kaggle_data():
    print("Authenticating with Kaggle API...")
    try:
        # Initialize and authenticate using the kaggle.json file
        api = KaggleApi()
        api.authenticate()
    except Exception as e:
        print(f"Authentication failed. Did you put kaggle.json in C:\\Users\\YourName\\.kaggle\\? Error: {e}")
        return

    dataset_name = 'nicapotato/womens-ecommerce-clothing-reviews'
    download_path = 'data_lake/raw_bronze/'
    
    print(f"Downloading dataset '{dataset_name}'...")
    
    # Download the files to our raw_bronze folder
    api.dataset_download_files(dataset_name, path=download_path, unzip=False)
    
    # Unzip the file
    zip_file_path = f"{download_path}/womens-ecommerce-clothing-reviews.zip"
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(download_path)
    
    # Clean up the zip file so we only have the CSV
    os.remove(zip_file_path)
    
    print("Download complete. Processing and splitting data...")
    
    # Read the downloaded CSV
    csv_file = f"{download_path}/Womens Clothing E-Commerce Reviews.csv"
    df = pd.read_csv(csv_file, index_col=0) # Column 0 is an unnamed ID column
    
    # Rename columns to be database-friendly (lowercase, underscores)
    df.columns = ['clothing_id', 'age', 'title', 'review_text', 'rating', 
                  'recommended_ind', 'positive_feedback_count', 'division_name', 
                  'department_name', 'class_name']
    
    # Create a unique Review ID for our database
    df['review_id'] = [f"rev_{i}" for i in range(len(df))]
    
    # --- SPLIT 1: STRUCTURED DATA ---
    # We take everything EXCEPT the messy text columns
    df_structured = df[['review_id', 'clothing_id', 'age', 'rating', 'recommended_ind', 
                        'positive_feedback_count', 'division_name', 'department_name', 'class_name']]
    
    struct_path = f"{download_path}/structured_sales_data.csv"
    df_structured.to_csv(struct_path, index=False)
    
    # --- SPLIT 2: UNSTRUCTURED DATA ---
    # We take the ID, the Title, and the massively long Review Text
    df_unstructured = df[['review_id', 'clothing_id', 'title', 'review_text']]
    
    unstruct_path = f"{download_path}/unstructured_reviews.csv"
    df_unstructured.to_csv(unstruct_path, index=False)
    
    # Clean up the original massive downloaded file to save space
    os.remove(csv_file)
    
    print("\n✅ DAY 1 COMPLETE: DATA INGESTION SUCCESSFUL")
    print(f"-> Extracted {len(df_structured)} rows of Structured Data to {struct_path}")
    print(f"-> Extracted {len(df_unstructured)} blocks of Unstructured Text to {unstruct_path}")

# Run the pipeline
ingest_kaggle_data()