import httpx
import pandas as pd

# FIX 1: Change this to the actual structured data API path
LIVE_API_URL = "https://weworkremotely.com"

# FIX 2: Emulate a complete browser signature to prevent firewall blocks
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin'
}

def pull_realtime_jobs(url):
    print(f"📡 Polling real-time data from: {url}")
    try:
        # Force HTTP/2 to perfectly replicate modern desktop browsers
        with httpx.Client(http2=True, headers=HEADERS, timeout=15.0) as client:
            response = client.get(url)
            
        if response.status_code != 200:
            print(f"❌ Failed to reach API. Status code: {response.status_code}")
            return None
            
        data = response.json()
        jobs = data.get('jobs', [])
        print(f"✅ Successfully found {len(jobs)} active listings live on the board.")
        
        processed_records = []
        for job in jobs:
            record = {
                'job_id': job.get('id'),
                'company': job.get('company'),
                'title': job.get('title'),
                'category': job.get('category'),
                'job_type': job.get('job_type'),
                'url': job.get('url'),
                'publication_date': job.get('publication_date'),
                'ingestion_date': pd.Timestamp.now().strftime('%Y-%m-%d')
            }
            processed_records.append(record)
            
        return processed_records

    except Exception as e:
        print(f"💥 Error processing stream: {e}")
        return None

# Execute live read pull
live_data = pull_realtime_jobs(LIVE_API_URL)

if live_data:
    df_live = pd.DataFrame(live_data)
    print("\n--- Live Data Snapshot ---")
    print(df_live[['company', 'title', 'publication_date']].head(5))
