import pandas as pd
import numpy as np
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from textblob import TextBlob
from transformers import pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from tqdm import tqdm # This gives us a progress bar!
import os
import nltk

# Download VADER dictionary
nltk.download('vader_lexicon', quiet=True)

def build_meta_classifier():
    print("--- 1. Loading Bronze Data ---")
    # We need BOTH files because the Star Ratings (our target) are in the structured file
    # and the text is in the unstructured file.
    df_struct = pd.read_csv('data_lake/raw_bronze/structured_sales_data.csv')
    df_unstruct = pd.read_csv('data_lake/raw_bronze/unstructured_reviews.csv')
    
    # Merge them together based on the review_id
    df = pd.merge(df_unstruct, df_struct[['review_id', 'rating']], on='review_id')
    df = df.dropna(subset=['review_text', 'rating'])
    
    # ⚠️ PERFORMANCE LIMITER: We only take the first 500 rows so your laptop doesn't melt.
    # To process all 23,000 rows, comment out the line below.
    df = df.head(500).copy() 
    
    print(f"Processing {len(df)} reviews for ML feature extraction...")

    # Initialize Base Models
    sia = SentimentIntensityAnalyzer()
    
    # Initialize Hugging Face Deep Learning Pipeline (DistilBERT)
    print("Loading Deep Learning Model (This takes a moment)...")
    # We truncate to 512 tokens to prevent crashing on extremely long reviews
    hf_pipeline = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english", truncation=True)

    vader_scores = []
    textblob_scores = []
    hf_scores = []

    print("\n--- 2. Extracting Features (AI Processing) ---")
    # tqdm gives us a beautiful progress bar in the terminal
    for index, row in tqdm(df.iterrows(), total=len(df), desc="Analyzing Text"):
        text = str(row['review_text'])
        
        # A. VADER Feature (-1 to 1)
        vader_scores.append(sia.polarity_scores(text)['compound'])
        
        # B. TextBlob Feature (-1 to 1)
        textblob_scores.append(TextBlob(text).sentiment.polarity)
        
        # C. Hugging Face Feature
        try:
            hf_result = hf_pipeline(text)[0]
            # Convert to -1 to 1 scale. If Positive, use the probability. If Negative, make it negative.
            if hf_result['label'] == 'POSITIVE':
                hf_scores.append(hf_result['score'])
            else:
                hf_scores.append(-hf_result['score'])
        except:
            hf_scores.append(0) # Fallback if the model fails on weird text

    # Add features to dataframe
    df['feat_vader'] = vader_scores
    df['feat_textblob'] = textblob_scores
    df['feat_huggingface'] = hf_scores

    print("\n--- 3. Training the Meta-Classifier (Random Forest) ---")
    
    # Our target is to predict if a review is generally Good (4-5 stars) or Bad (1-3 stars)
    # 1 = Positive Review, 0 = Negative Review
    df['target_sentiment'] = np.where(df['rating'] >= 4, 1, 0)
    
    # Define our Features (X) and Target (y)
    X = df[['feat_vader', 'feat_textblob', 'feat_huggingface']]
    y = df['target_sentiment']
    
    # Split into Training Data (80%) and Testing Data (20%)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Initialize and Train the Random Forest
    rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_model.fit(X_train, y_train)
    
    # Test the model to see how smart it is
    predictions = rf_model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    print(f"Meta-Classifier Accuracy: {accuracy * 100:.2f}%")
    print("The model learned when to trust VADER vs Hugging Face!")

    print("\n--- 4. Applying Final Predictions ---")
    # Apply the trained brain to all rows to get our final predicted class (1 or 0)
    df['final_ai_prediction'] = rf_model.predict(X)
    
    # Convert the 1 and 0 back into human readable labels for our PowerBI Dashboard
    df['final_sentiment_label'] = np.where(df['final_ai_prediction'] == 1, 'Positive', 'Negative')
    
    # Clean up the Dataframe to only keep the final structured results
    df_silver_sentiment = df[['review_id', 'clothing_id', 'feat_vader', 'feat_textblob', 'feat_huggingface', 'final_sentiment_label']]
    
    # Save to Silver Layer
    os.makedirs('data_lake/processed_silver', exist_ok=True)
    silver_path = 'data_lake/processed_silver/ai_sentiment_model_results.csv'
    df_silver_sentiment.to_csv(silver_path, index=False)
    
    print(f"\n✅ AI Processing complete. Final predictions saved to {silver_path}")
    print("\nPreview of the new Meta-Classifier Data:")
    print(df_silver_sentiment[['review_id', 'feat_vader', 'feat_huggingface', 'final_sentiment_label']].head())

if __name__ == "__main__":
    build_meta_classifier()