import sqlite3
import pandas as pd
import os

def build_data_warehouse():
    print("--- 1. Connecting to Data Warehouse ---")
    # This will create a new file called 'shoptrend_warehouse.db' in your project folder.
    # If it already exists, it will just connect to it.
    db_path = 'shoptrend_warehouse.db'
    conn = sqlite3.connect(db_path)
    
    print("✅ Connected to SQLite Database.")

    print("\n--- 2. Loading Silver Data into Staging Tables ---")
    # Load our two silver CSVs
    # Note: Ensure you copied structured_sales_data.csv to the silver folder and renamed it!
    # If not, we will just read it straight from bronze for this step.
    try:
        df_struct = pd.read_csv('data_lake/processed_silver/clean_structured_data.csv')
    except:
        print("Reading structured data from bronze (fallback)...")
        df_struct = pd.read_csv('data_lake/raw_bronze/structured_sales_data.csv')
        
    df_ai = pd.read_csv('data_lake/processed_silver/ai_sentiment_model_results.csv')

    # Send dataframes to SQL database (This is magic - Pandas does all the hard work!)
    df_struct.to_sql('stg_sales_data', conn, if_exists='replace', index=False)
    df_ai.to_sql('stg_ai_sentiment', conn, if_exists='replace', index=False)
    
    print("✅ Silver data loaded into SQL tables: 'stg_sales_data' & 'stg_ai_sentiment'")

    print("\n--- 3. Executing SQL Transformation (Building the Gold Layer) ---")
    # We create a cursor to run actual SQL commands
    cursor = conn.cursor()
    
    # This is a real-world ELT (Extract, Load, Transform) pattern.
    # We join our Sales data with our AI data to create a final, perfect table for Power BI.
    sql_query = """
    CREATE TABLE IF NOT EXISTS gold_product_analytics AS
    SELECT 
        s.review_id,
        s.clothing_id,
        s.age,
        s.department_name,
        s.class_name,
        s.rating AS actual_star_rating,
        s.recommended_ind AS is_recommended,
        ai.feat_vader,
        ai.feat_huggingface,
        ai.final_sentiment_label
    FROM 
        stg_sales_data s
    JOIN 
        stg_ai_sentiment ai ON s.review_id = ai.review_id;
    """
    
    # First, drop the gold table if we are re-running the script
    cursor.execute("DROP TABLE IF EXISTS gold_product_analytics")
    
    # Execute our massive join query
    cursor.execute(sql_query)
    conn.commit()
    
    print("✅ SQL Transformation complete. 'gold_product_analytics' table created.")

    print("\n--- 4. Verifying the Gold Data ---")
    # Let's run a quick query to see our final table!
    verification_query = "SELECT * FROM gold_product_analytics LIMIT 5;"
    final_df = pd.read_sql_query(verification_query, conn)
    print("\nPreview of your final Data Warehouse Gold Table:")
    print(final_df[['clothing_id', 'department_name', 'actual_star_rating', 'final_sentiment_label']])

    # Close the database connection
    conn.close()

if __name__ == "__main__":
    build_data_warehouse()
    print("\n🎉 DAY 3 COMPLETE: DATA WAREHOUSE & SQL TRANSFORMATION SUCCESSFUL")