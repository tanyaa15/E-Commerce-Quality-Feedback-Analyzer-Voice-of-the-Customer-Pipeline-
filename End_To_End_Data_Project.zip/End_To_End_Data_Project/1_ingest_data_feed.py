import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import re

# This is the raw data feed for the job board, not the visual webpage.
RSS_FEED_URL = 'https://weworkremotely.com/categories/remote-programming-jobs.rss'

def ingest_job_data():
    print(f"Connecting to data feed: {RSS_FEED_URL}")
    response = requests.get(RSS_FEED_URL)
    
    # We parse it as XML because RSS feeds are written in XML
    soup = BeautifulSoup(response.content, 'xml')
    
    # In an RSS feed, every job is inside an <item> tag
    job_items = soup.find_all('item')
    
    print(f"Successfully found {len(job_items)} jobs in the data feed. Processing...\n")
    
    structured_data = []
    unstructured_data = []
    
    for item in job_items:
        # 1. Extracting the raw text from XML tags
        title_raw = item.find('title').text
        link = item.find('link').text
        pub_date = item.find('pubDate').text
        raw_html_description = item.find('description').text
        
        # 2. Cleaning up the title (WWR formats them as "Company: Job Title")
        if ':' in title_raw:
            company = title_raw.split(':')[0].strip()
            job_title = title_raw.split(':')[1].strip()
        else:
            company = "Unknown"
            job_title = title_raw
            
        # 3. Create a unique ID from the URL
        job_id_string = link.split('/')[-1]
        job_id = f"job_{job_id_string.split('-')[0]}"
        
        # 4. Clean the unstructured description (Remove HTML tags like <br> or <p>)
        # We use a simple Regular Expression (re) to strip HTML tags from the description
        clean_text_description = re.sub('<[^<]+>', ' ', raw_html_description).strip()
        
        # 5. Append to Structured List
        structured_data.append({
            'job_id': job_id,
            'company': company,
            'job_title': job_title,
            'date_posted': pub_date,
            'job_url': link,
            'ingestion_date': datetime.now().strftime("%Y-%m-%d")
        })
        
        # 6. Append to Unstructured List
        unstructured_data.append({
            'desc_id': f"desc_{job_id}",
            'job_id': job_id,
            'raw_job_description': clean_text_description
        })

    return structured_data, unstructured_data

# --- Execute the Pipeline ---
structured, unstructured = ingest_job_data()

if structured and unstructured:
    # Save Structured Data
    df_structured = pd.DataFrame(structured)
    struct_path = 'data_lake/raw_bronze/structured_jobs.csv'
    df_structured.to_csv(struct_path, index=False)
    
    # Save Unstructured Data
    df_unstructured = pd.DataFrame(unstructured)
    unstruct_path = 'data_lake/raw_bronze/unstructured_job_descriptions.csv'
    df_unstructured.to_csv(unstruct_path, index=False)
    
    print("✅ DAY 1 COMPLETE: DATA INGESTION SUCCESSFUL")
    print(f"-> Saved {len(df_structured)} rows to {struct_path}")
    print(f"-> Saved {len(df_unstructured)} text blocks to {unstruct_path}")
    
    print("\nPreview of Structured Data:")
    print(df_structured[['company', 'job_title']].head(3))
else:
    print("Failed to ingest data.")